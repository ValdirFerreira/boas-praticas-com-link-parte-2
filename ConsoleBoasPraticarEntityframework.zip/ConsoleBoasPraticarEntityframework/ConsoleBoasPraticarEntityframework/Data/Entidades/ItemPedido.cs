﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleBoasPraticarEntityframework.Data.Entidades
{
    public class ItemPedido
    {
        public int Id { get; set; }
        public string NomeItem { get; set; }
        public int IdPedido { get; set; }
    }
}
