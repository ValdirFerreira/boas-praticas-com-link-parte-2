﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleBoasPraticarEntityframework.Data.Entidades
{
    public  class Pedido
    {
        public int Id { get; set; }
        public string NomePedido { get; set; }
    }
}
