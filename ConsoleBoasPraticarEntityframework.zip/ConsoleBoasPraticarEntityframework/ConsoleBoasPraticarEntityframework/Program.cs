﻿using ConsoleBoasPraticarEntityframework.Data;
using ConsoleBoasPraticarEntityframework.Data.Entidades;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConsoleBoasPraticarEntityframework
{
    public class Program
    {
        async static Task Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //await CriaBase();
            await ConsultasAsNoTracking();
            await FormasConsulta();
            await ConsultasSomenteNecessario();
            await FiltrosMemoria();
            await ConsultasSimplificada();
            await ConsultasNOLOCK();
        }


        /// <summary>
        /// Utilizando AsNoTracking
        /// </summary>
        public async static Task ConsultasAsNoTracking()
        {
            using (var dataBase = new Contexto())
            {
                var query = from Item in dataBase.ItemPedido
                            where Item.IdPedido > 0
                            select Item;

                var resultado = await query.AsNoTracking().Select(i => new { i.NomeItem }).ToListAsync();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Item - ", item.NomeItem));
                }

                Console.Read();
            };
        }


        /// <summary>
        ///  Formas de consultas
        /// </summary>
        public async static Task FormasConsulta()
        {

            // CORRETA
            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3
                            select new { Pedido = Pred.NomePedido, NomeItem = Item.NomeItem };

                var resultado = await query.AsNoTracking().ToListAsync();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Pedido, "  -  Item : ", item.NomeItem));
                }

                Console.Read();



            }
        }


        /// <summary>
        ///  Consultas somente o necessario
        /// </summary>
        public async static Task ConsultasSomenteNecessario()
        {

            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3
                            select new { Pedido = Pred.NomePedido, NomeItem = Item.NomeItem };

                var resultado = await query.AsNoTracking().ToListAsync();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Pedido, "  -  Item : ", item.NomeItem));
                }

                Console.Read();

            }
        }


        /// <summary>
        ///  Filtros em memoria
        /// </summary>
        public async static Task FiltrosMemoria()
        {


            // CORRETO
            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.NomePedido.Contains('P') && Pred.NomePedido.StartsWith('P')
                            select Pred;

                var resultado = await query.AsNoTracking().Select(i => new { i.Id, i.NomePedido }).ToListAsync();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.Id, "  -  Nome : ", item.NomePedido));
                }

                Console.Read();
            }


            /// CORRETO 


        }

        /// <summary>
        ///  Consultas Simplificadas
        /// </summary>
        public async static Task ConsultasSimplificada()
        {

            using (var dataBase = new Contexto())
            {
                var query = from Pred in dataBase.Pedido
                            join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                            where Pred.Id < 3

                            select new Pedido
                            {
                                NomePedido = Pred.NomePedido
                            };

                var resultado = await query.AsNoTracking().ToListAsync();

                foreach (var item in resultado)
                {
                    Console.WriteLine(string.Concat("Pedido : ", item.NomePedido));
                }

                Console.Read();

            }
        }


        /// <summary>
        ///  Consultas SimpliNOLOCKficadas
        /// </summary>
        public async static Task ConsultasNOLOCK()
        {

            using (var dataBase = new Contexto())
            {

                using (var tran = await dataBase.Database.BeginTransactionAsync(System.Data.IsolationLevel.ReadUncommitted))
                {

                    var query = from Pred in dataBase.Pedido
                                join Item in dataBase.ItemPedido on Pred.Id equals Item.IdPedido

                                where Pred.Id < 3
                                select new Pedido
                                {
                                    NomePedido = Pred.NomePedido
                                };

                    var resultado = await query.AsNoTracking().ToListAsync();

                    foreach (var item in resultado)
                    {
                        Console.WriteLine(string.Concat("Pedido : ", item.NomePedido));
                    }

                    Console.Read();

                    tran.Commit();
                }

            }
        }




        /// <summary>
        /// 
        /// </summary>
        public async static Task CriaBase()
        {
            using (var dataBase = new Contexto())
            {
                for (int i = 1; i <= 5; i++)
                {
                    var _Pedido = dataBase.Pedido.Add(new Pedido
                    {
                        NomePedido = string.Concat("Pedido Numero: ", i.ToString())
                    });

                    await dataBase.SaveChangesAsync();
                    var ListaItensPedido = new List<ItemPedido>();

                    for (int y = 1; y < 100; y++)
                    {
                        ListaItensPedido.Add(new ItemPedido
                        {
                            IdPedido = _Pedido.Entity.Id,
                            NomeItem = string.Concat("Nome item Numero: ", y.ToString())
                        });
                    }

                    dataBase.ItemPedido.AddRange(ListaItensPedido);

                    await dataBase.SaveChangesAsync();
                }

            }
        }

    }
}
